package com.metflix.app;

import android.content.Context;
import android.content.SharedPreferences;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

public class PrefsManager {
    private static final String PREFS_NAME = "metflix_native_prefs";

    public static final String KEY_DOWNLOADER = "downloader_mode";
    public static final String KEY_QUALITY = "default_quality";
    public static final String KEY_SHOW_SUBS = "show_subtitles";
    public static final String KEY_SUB_LANG = "subtitle_lang";
    public static final String KEY_AUDIO_LANG = "audio_lang";
    public static final String KEY_AUTO_SWITCH = "auto_switch_server";
    public static final String KEY_KEEP_SERVER = "keep_server_on_error";
    public static final String KEY_BLOCK_POPUPS = "block_popups";
    public static final String KEY_AD_FILTER = "ad_domain_filter";
    public static final String KEY_PRIMARY_SERVER = "primary_server";
    public static final String KEY_ENABLED_SERVERS = "enabled_servers";

    public static final String[] ALL_SERVERS = new String[]{
        "Nitro - [Multi-Lang]",
        "VidHindi",
        "Wahalala - [Multi-Lang]",
        "Multi-bill-[Multi-Lang]",
        "AwsPly-[Multi-Lang]",
        "Multi-blue-[Multi-Lang]",
        "Xuhd-[Multi-Lang]",
        "ZokoAnime",
        "Citadel",
        "CastVid",
        "StremFx",
        "XDrop",
        "PureWave",
        "Vixo",
        "Prvibd",
        "Stvvid",
        "Ophn"
    };

    private final SharedPreferences prefs;

    public PrefsManager(Context context) {
        this.prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
    }

    public String getDownloaderMode() { return prefs.getString(KEY_DOWNLOADER, "Internal"); }
    public void setDownloaderMode(String v) { prefs.edit().putString(KEY_DOWNLOADER, v).apply(); }

    public String getQuality() { return prefs.getString(KEY_QUALITY, "Auto"); }
    public void setQuality(String v) { prefs.edit().putString(KEY_QUALITY, v).apply(); }

    public boolean isShowSubtitles() { return prefs.getBoolean(KEY_SHOW_SUBS, false); }
    public void setShowSubtitles(boolean v) { prefs.edit().putBoolean(KEY_SHOW_SUBS, v).apply(); }

    public String getSubtitleLang() { return prefs.getString(KEY_SUB_LANG, "en"); }
    public void setSubtitleLang(String v) { prefs.edit().putString(KEY_SUB_LANG, v).apply(); }

    public String getAudioLang() { return prefs.getString(KEY_AUDIO_LANG, "hi"); }
    public void setAudioLang(String v) { prefs.edit().putString(KEY_AUDIO_LANG, v).apply(); }

    public boolean isAutoSwitchServer() { return prefs.getBoolean(KEY_AUTO_SWITCH, true); }
    public void setAutoSwitchServer(boolean v) { prefs.edit().putBoolean(KEY_AUTO_SWITCH, v).apply(); }

    public boolean isKeepServerOnError() { return prefs.getBoolean(KEY_KEEP_SERVER, false); }
    public void setKeepServerOnError(boolean v) { prefs.edit().putBoolean(KEY_KEEP_SERVER, v).apply(); }

    public boolean isBlockPopups() { return prefs.getBoolean(KEY_BLOCK_POPUPS, true); }
    public void setBlockPopups(boolean v) { prefs.edit().putBoolean(KEY_BLOCK_POPUPS, v).apply(); }

    public boolean isAdFilterEnabled() { return prefs.getBoolean(KEY_AD_FILTER, true); }
    public void setAdFilterEnabled(boolean v) { prefs.edit().putBoolean(KEY_AD_FILTER, v).apply(); }

    public String getPrimaryServer() { return prefs.getString(KEY_PRIMARY_SERVER, "Nitro - [Multi-Lang]"); }
    public void setPrimaryServer(String v) { prefs.edit().putString(KEY_PRIMARY_SERVER, v).apply(); }

    public Set<String> getEnabledServers() {
        Set<String> def = new HashSet<>(Arrays.asList(ALL_SERVERS));
        return new HashSet<>(prefs.getStringSet(KEY_ENABLED_SERVERS, def));
    }
    public void setEnabledServers(Set<String> set) {
        prefs.edit().putStringSet(KEY_ENABLED_SERVERS, set).apply();
    }
}
