package com.metflix.app;

import android.net.Uri;
import android.webkit.WebResourceResponse;
import java.io.ByteArrayInputStream;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

public class AdBlocker {
    private static final Set<String> BLOCKED_DOMAINS = new HashSet<>(Arrays.asList(
        "doubleclick.net",
        "googlesyndication.com",
        "googleadservices.com",
        "adservice.google.com",
        "popads.net",
        "popcash.net",
        "propellerads.com",
        "adsterra.com",
        "highperformanceformat.com",
        "profitablegatecpm.com",
        "effectivegatecpm.com",
        "monetag.com",
        "exoclick.com",
        "juicyads.com",
        "trafficjunky.net",
        "hilltopads.net",
        "clickadu.com",
        "adcash.com",
        "acscdn.com",
        "mc.yandex.ru",
        "taboola.com",
        "outbrain.com",
        "mgid.com",
        "revcontent.com",
        "histats.com",
        "tsyndicate.com",
        "realsrv.com",
        "betterbanners.org",
        "ad-maven.com",
        "alwingulla.com",
        "inpagepush.com",
        "pushame.com",
        "notifpush.com"
    ));

    private static final Set<String> ALLOWED_NAVIGATION_HOSTS = new HashSet<>(Arrays.asList(
        "metflixstream.netlify.app",
        "murshidislam001-wq.github.io",
        "nxsha.space",
        "nxsha.app",
        "vidsrc.sh",
        "youtube.com",
        "youtu.be",
        "themoviedb.org"
    ));

    public static boolean isAdUrl(String url) {
        if (url == null) return false;
        String lower = url.toLowerCase();
        try {
            Uri uri = Uri.parse(lower);
            String host = uri.getHost();
            if (host == null) return false;
            for (String blocked : BLOCKED_DOMAINS) {
                if (host.equals(blocked) || host.endsWith("." + blocked)) {
                    return true;
                }
            }
            if (lower.contains("/popunder") || lower.contains("popads") || lower.contains("/ads.js")) {
                return true;
            }
        } catch (Exception ignored) {}
        return false;
    }

    public static boolean isAllowedNavigation(String url) {
        if (url == null) return false;
        try {
            Uri uri = Uri.parse(url.toLowerCase());
            String host = uri.getHost();
            if (host == null) return false;
            for (String allowed : ALLOWED_NAVIGATION_HOSTS) {
                if (host.equals(allowed) || host.endsWith("." + allowed)) {
                    return true;
                }
            }
        } catch (Exception ignored) {}
        return false;
    }

    public static WebResourceResponse createEmptyResponse() {
        return new WebResourceResponse(
            "text/plain",
            "utf-8",
            new ByteArrayInputStream("".getBytes())
        );
    }
}
