package com.metflix.app;

import android.app.DownloadManager;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SwitchCompat;
import java.util.Set;

public class SettingsActivity extends AppCompatActivity {

    public static boolean settingsChanged = false;
    private PrefsManager prefs;
    private TextView valDownloader, valQuality, valSubLang, valAudioLang, valPrimaryServer, valEnabledServers;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = new PrefsManager(this);

        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(Color.parseColor("#07070C"));
        scroll.setFillViewport(true);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        int pad = dp(20);
        root.setPadding(pad, dp(16), pad, dp(36));

        // Top Bar
        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setPadding(0, 0, 0, dp(22));

        TextView backBtn = new TextView(this);
        backBtn.setText("←");
        backBtn.setTextColor(Color.parseColor("#F8F9FC"));
        backBtn.setTextSize(TypedValue.COMPLEX_UNIT_SP, 20);
        backBtn.setGravity(Gravity.CENTER);
        backBtn.setBackgroundResource(R.drawable.bg_fab_settings);
        LinearLayout.LayoutParams backParams = new LinearLayout.LayoutParams(dp(40), dp(40));
        backParams.setMargins(0, 0, dp(14), 0);
        backBtn.setLayoutParams(backParams);
        backBtn.setOnClickListener(v -> finish());
        header.addView(backBtn);

        LinearLayout titleCol = new LinearLayout(this);
        titleCol.setOrientation(LinearLayout.VERTICAL);
        TextView eyebrow = new TextView(this);
        eyebrow.setText("YOUR PREFERENCES");
        eyebrow.setTextColor(Color.parseColor("#9A9EB2"));
        eyebrow.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10);
        eyebrow.setTypeface(null, Typeface.BOLD);
        titleCol.addView(eyebrow);

        TextView title = new TextView(this);
        title.setText("App & Player Settings");
        title.setTextColor(Color.parseColor("#F8F9FC"));
        title.setTextSize(TypedValue.COMPLEX_UNIT_SP, 20);
        title.setTypeface(null, Typeface.BOLD);
        titleCol.addView(title);
        header.addView(titleCol);
        root.addView(header);

        // SECTION 1: DOWNLOADS
        addSectionHeader(root, "Downloads", "Manage offline videos and download preferences.");
        LinearLayout cardDownloads = createCard();
        valDownloader = addActionRow(cardDownloads, "Download Settings", prefs.getDownloaderMode(), v -> showDownloaderDialog());
        addDivider(cardDownloads);
        addActionRow(cardDownloads, "Manage Downloads", "Open", v -> {
            try {
                startActivity(new Intent(DownloadManager.ACTION_VIEW_DOWNLOADS));
            } catch (Exception e) {
                Toast.makeText(this, "Unable to open Downloads folder", Toast.LENGTH_SHORT).show();
            }
        });
        root.addView(cardDownloads);

        // SECTION 2: PLAYER DEFAULTS
        addSectionHeader(root, "Player Defaults", "Set your preferred video and audio experience.");
        LinearLayout cardPlayer = createCard();
        valQuality = addActionRow(cardPlayer, "Default Video Quality", prefs.getQuality(), v -> showQualityDialog());
        addDivider(cardPlayer);
        addToggleRow(cardPlayer, "Show Subtitles By Default", prefs.isShowSubtitles(), checked -> {
            settingsChanged = true; prefs.setShowSubtitles(checked);
            Toast.makeText(this, checked ? "Subtitles enabled by default" : "Subtitles hidden by default", Toast.LENGTH_SHORT).show();
        });
        addDivider(cardPlayer);
        valSubLang = addActionRow(cardPlayer, "Default Subtitle Language", langLabel(prefs.getSubtitleLang()), v -> showLanguageDialog(true));
        addDivider(cardPlayer);
        valAudioLang = addActionRow(cardPlayer, "Default Audio Language", langLabel(prefs.getAudioLang()), v -> showLanguageDialog(false));
        root.addView(cardPlayer);

        // SECTION 3: ERROR HANDLING RULES
        addSectionHeader(root, "Error Handling Rules", "Choose how Metflix handles unavailable sources.");
        LinearLayout cardErrors = createCard();
        addToggleRow(cardErrors, "Auto Switch Server On Fail", prefs.isAutoSwitchServer(), checked -> { settingsChanged = true; prefs.setAutoSwitchServer(checked); });
        addDivider(cardErrors);
        addToggleRow(cardErrors, "Keep Server On Error", prefs.isKeepServerOnError(), checked -> { settingsChanged = true; prefs.setKeepServerOnError(checked); });
        root.addView(cardErrors);

        // SECTION 4: AD-BLOCK & POP-UP SHIELD
        addSectionHeader(root, "Ad-Block & Shield", "Built-in native protection for video embeds.");
        LinearLayout cardShield = createCard();
        addToggleRow(cardShield, "Block Pop-ups & Ad Redirects", prefs.isBlockPopups(), checked -> { settingsChanged = true; prefs.setBlockPopups(checked); });
        addDivider(cardShield);
        addToggleRow(cardShield, "Filter Ad Domains", prefs.isAdFilterEnabled(), checked -> { settingsChanged = true; prefs.setAdFilterEnabled(checked); });
        root.addView(cardShield);

        // SECTION 5: SERVER MANAGEMENT
        addSectionHeader(root, "Server Management", "Enable servers and change their priority.");
        LinearLayout cardServers = createCard();
        valPrimaryServer = addActionRow(cardServers, "Primary Priority Server", prefs.getPrimaryServer(), v -> showPrimaryServerDialog());
        addDivider(cardServers);
        valEnabledServers = addActionRow(cardServers, "Enabled Servers", prefs.getEnabledServers().size() + " Active", v -> showEnabledServersDialog());
        root.addView(cardServers);

        scroll.addView(root);
        setContentView(scroll);
    }

    private void showDownloaderDialog() {
        String[] options = {"Internal", "1DM"};
        new AlertDialog.Builder(this)
            .setTitle("Download Settings")
            .setItems(options, (d, which) -> {
                settingsChanged = true; prefs.setDownloaderMode(options[which]);
                valDownloader.setText(options[which] + "  ›");
            }).show();
    }

    private void showQualityDialog() {
        String[] options = {"Auto", "1080p Full HD", "720p HD", "480p SD"};
        new AlertDialog.Builder(this)
            .setTitle("Default Video Quality")
            .setItems(options, (d, which) -> {
                settingsChanged = true; prefs.setQuality(options[which]);
                valQuality.setText(options[which] + "  ›");
            }).show();
    }

    private void showLanguageDialog(boolean isSubtitle) {
        String[] labels = {"Hindi", "English", "Spanish", "French", "Auto"};
        String[] codes = {"hi", "en", "es", "fr", ""};
        new AlertDialog.Builder(this)
            .setTitle(isSubtitle ? "Default Subtitle Language" : "Default Audio Language")
            .setItems(labels, (d, which) -> {
                if (isSubtitle) {
                    settingsChanged = true; prefs.setSubtitleLang(codes[which]);
                    valSubLang.setText(labels[which] + "  ›");
                } else {
                    settingsChanged = true; prefs.setAudioLang(codes[which]);
                    valAudioLang.setText(labels[which] + "  ›");
                }
            }).show();
    }

    private void showPrimaryServerDialog() {
        new AlertDialog.Builder(this)
            .setTitle("Primary Priority Server")
            .setItems(PrefsManager.ALL_SERVERS, (d, which) -> {
                String chosen = PrefsManager.ALL_SERVERS[which];
                settingsChanged = true; prefs.setPrimaryServer(chosen);
                valPrimaryServer.setText(chosen + "  ›");
            }).show();
    }

    private void showEnabledServersDialog() {
        Set<String> enabled = prefs.getEnabledServers();
        boolean[] checked = new boolean[PrefsManager.ALL_SERVERS.length];
        for (int i = 0; i < PrefsManager.ALL_SERVERS.length; i++) {
            checked[i] = enabled.contains(PrefsManager.ALL_SERVERS[i]);
        }
        new AlertDialog.Builder(this)
            .setTitle("Enable / Disable Servers")
            .setMultiChoiceItems(PrefsManager.ALL_SERVERS, checked, (d, which, isChecked) -> {
                if (isChecked) enabled.add(PrefsManager.ALL_SERVERS[which]);
                else enabled.remove(PrefsManager.ALL_SERVERS[which]);
            })
            .setPositiveButton("Save", (d, w) -> {
                settingsChanged = true; prefs.setEnabledServers(enabled);
                valEnabledServers.setText(enabled.size() + " Active  ›");
            })
            .setNegativeButton("Cancel", null)
            .show();
    }

    private String langLabel(String code) {
        if ("hi".equals(code)) return "Hindi";
        if ("en".equals(code)) return "English";
        if ("es".equals(code)) return "Spanish";
        if ("fr".equals(code)) return "French";
        return "Auto";
    }

    private void addSectionHeader(LinearLayout parent, String titleText, String subText) {
        TextView t = new TextView(this);
        t.setText(titleText);
        t.setTextColor(Color.parseColor("#F8F9FC"));
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
        t.setTypeface(null, Typeface.BOLD);
        t.setPadding(dp(2), dp(14), 0, dp(2));
        parent.addView(t);

        TextView s = new TextView(this);
        s.setText(subText);
        s.setTextColor(Color.parseColor("#8A8FA6"));
        s.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        s.setPadding(dp(2), 0, 0, dp(10));
        parent.addView(s);
    }

    private LinearLayout createCard() {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setBackgroundResource(R.drawable.bg_settings_card);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.setMargins(0, 0, 0, dp(8));
        card.setLayoutParams(lp);
        return card;
    }

    private TextView addActionRow(LinearLayout card, String label, String value, View.OnClickListener click) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(16), dp(15), dp(16), dp(15));
        row.setClickable(true);
        row.setOnClickListener(click);

        TextView lbl = new TextView(this);
        lbl.setText(label);
        lbl.setTextColor(Color.parseColor("#F8F9FC"));
        lbl.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
        lbl.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        row.addView(lbl);

        TextView val = new TextView(this);
        val.setText(value + "  ›");
        val.setTextColor(Color.parseColor("#A1A4B8"));
        val.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        row.addView(val);

        card.addView(row);
        return val;
    }

    private void addToggleRow(LinearLayout card, String label, boolean initial, OnToggleListener listener) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(16), dp(12), dp(16), dp(12));

        TextView lbl = new TextView(this);
        lbl.setText(label);
        lbl.setTextColor(Color.parseColor("#F8F9FC"));
        lbl.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
        lbl.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        row.addView(lbl);

        SwitchCompat sw = new SwitchCompat(this);
        sw.setChecked(initial);
        sw.setTrackTintList(new ColorStateList(
            new int[][]{new int[]{android.R.attr.state_checked}, new int[]{}},
            new int[]{Color.parseColor("#E50914"), Color.parseColor("#333344")}
        ));
        sw.setThumbTintList(ColorStateList.valueOf(Color.WHITE));
        sw.setOnCheckedChangeListener((buttonView, isChecked) -> listener.onToggle(isChecked));
        row.addView(sw);

        card.addView(row);
    }

    private void addDivider(LinearLayout card) {
        View div = new View(this);
        div.setBackgroundColor(Color.parseColor("#242434"));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 1);
        lp.setMargins(dp(16), 0, dp(16), 0);
        card.addView(div, lp);
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density);
    }

    interface OnToggleListener {
        void onToggle(boolean checked);
    }
}
