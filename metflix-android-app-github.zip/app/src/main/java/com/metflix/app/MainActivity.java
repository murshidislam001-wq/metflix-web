package com.metflix.app;

import android.annotation.SuppressLint;
import android.app.DownloadManager;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.Message;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.CookieManager;
import android.webkit.DownloadListener;
import android.webkit.URLUtil;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.Toast;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private static final String METFLIX_URL = "https://murshidislam001-wq.github.io/metflix-web/";
    private WebView webView;
    private FrameLayout rootLayout;
    private FrameLayout fullscreenContainer;
    private ImageButton settingsFab;
    private View customView;
    private WebChromeClient.CustomViewCallback customViewCallback;
    private PrefsManager prefs;
    private long lastBackPressTime = 0;

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = new PrefsManager(this);

        rootLayout = new FrameLayout(this);
        rootLayout.setBackgroundColor(Color.parseColor("#07070C"));

        webView = new WebView(this);
        webView.setBackgroundColor(Color.parseColor("#07070C"));
        rootLayout.addView(webView, new FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.MATCH_PARENT
        ));

        fullscreenContainer = new FrameLayout(this);
        fullscreenContainer.setBackgroundColor(Color.BLACK);
        fullscreenContainer.setVisibility(View.GONE);
        rootLayout.addView(fullscreenContainer, new FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.MATCH_PARENT
        ));

        // Discreet floating Settings button (bottom-right above mobile nav)
        settingsFab = new ImageButton(this);
        settingsFab.setBackgroundResource(R.drawable.bg_fab_settings);
        settingsFab.setImageResource(android.R.drawable.ic_menu_preferences);
        settingsFab.setColorFilter(Color.parseColor("#F8F9FC"));
        settingsFab.setContentDescription("App & Player Settings");
        int sizePx = (int) (46 * getResources().getDisplayMetrics().density);
        int marginRight = (int) (16 * getResources().getDisplayMetrics().density);
        int marginBottom = (int) (78 * getResources().getDisplayMetrics().density);
        FrameLayout.LayoutParams fabParams = new FrameLayout.LayoutParams(sizePx, sizePx);
        fabParams.gravity = Gravity.BOTTOM | Gravity.END;
        fabParams.setMargins(0, 0, marginRight, marginBottom);
        settingsFab.setOnClickListener(v -> startActivity(new Intent(this, SettingsActivity.class)));
        rootLayout.addView(settingsFab, fabParams);

        setContentView(rootLayout);
        setupWebView();
        webView.loadUrl(METFLIX_URL);
    }

    @SuppressLint("SetJavaScriptEnabled")
    private void setupWebView() {
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setAllowFileAccess(true);
        settings.setLoadWithOverviewMode(true);
        settings.setUseWideViewPort(true);
        settings.setSupportMultipleWindows(true);
        settings.setJavaScriptCanOpenWindowsAutomatically(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);

        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(webView, true);

        webView.setWebViewClient(new WebViewClient() {
            @Nullable
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                if (prefs.isAdFilterEnabled()) {
                    String url = request.getUrl().toString();
                    if (AdBlocker.isAdUrl(url)) {
                        return AdBlocker.createEmptyResponse();
                    }
                }
                return super.shouldInterceptRequest(view, request);
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                String url = request.getUrl().toString();
                if (url.contains("/dl/movie/") || url.contains("/dl/tv/")) {
                    handleDownloadUrl(url, null, null);
                    return true;
                }
                if (prefs.isBlockPopups()) {
                    if (AdBlocker.isAdUrl(url) || !AdBlocker.isAllowedNavigation(url)) {
                        return true; // Silently block pop-up redirect
                    }
                }
                return false;
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                syncPreferencesToWeb();
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onCreateWindow(WebView view, boolean isDialog, boolean isUserGesture, Message resultMsg) {
                // Block pop-up windows spawned by third-party video embeds
                if (prefs.isBlockPopups()) {
                    return false;
                }
                return super.onCreateWindow(view, isDialog, isUserGesture, resultMsg);
            }

            @Override
            public void onShowCustomView(View view, CustomViewCallback callback) {
                if (customView != null) {
                    onHideCustomView();
                    return;
                }
                customView = view;
                customViewCallback = callback;
                fullscreenContainer.addView(customView, new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT
                ));
                fullscreenContainer.setVisibility(View.VISIBLE);
                settingsFab.setVisibility(View.GONE);
                setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE);
                hideSystemUI();
            }

            @Override
            public void onHideCustomView() {
                exitFullscreen();
            }
        });

        webView.setDownloadListener(new DownloadListener() {
            @Override
            public void onDownloadStart(String url, String userAgent, String contentDisposition, String mimetype, long contentLength) {
                handleDownloadUrl(url, contentDisposition, mimetype);
            }
        });
    }

    private void handleDownloadUrl(String url, @Nullable String contentDisposition, @Nullable String mimetype) {
        String mode = prefs.getDownloaderMode();
        if ("1DM".equalsIgnoreCase(mode)) {
            try {
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                intent.setPackage("idm.internet.download.manager");
                startActivity(intent);
                return;
            } catch (Exception e) {
                try {
                    Intent intentPlus = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                    intentPlus.setPackage("idm.internet.download.manager.plus");
                    startActivity(intentPlus);
                    return;
                } catch (Exception ex) {
                    Toast.makeText(this, "1DM not installed — opening in browser", Toast.LENGTH_SHORT).show();
                    startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
                    return;
                }
            }
        }

        // Internal Android DownloadManager for direct files, or browser for /dl/ pages
        if (url.contains("/dl/movie/") || url.contains("/dl/tv/")) {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
            return;
        }
        try {
            DownloadManager.Request req = new DownloadManager.Request(Uri.parse(url));
            String fileName = URLUtil.guessFileName(url, contentDisposition, mimetype);
            req.setTitle(fileName);
            req.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
            req.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, fileName);
            DownloadManager dm = (DownloadManager) getSystemService(DOWNLOAD_SERVICE);
            if (dm != null) {
                dm.enqueue(req);
                Toast.makeText(this, "Downloading " + fileName, Toast.LENGTH_SHORT).show();
            }
        } catch (Exception e) {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
        }
    }

    private void syncPreferencesToWeb() {
        String server = prefs.getPrimaryServer().replace("'", "\\'");
        String audio = prefs.getAudioLang().replace("'", "\\'");
        String sub = prefs.isShowSubtitles() ? prefs.getSubtitleLang().replace("'", "\\'") : "";
        String quality = prefs.getQuality().replace("'", "\\'");
        boolean autoSwitch = prefs.isAutoSwitchServer();
        boolean keepServer = prefs.isKeepServerOnError();

        String js = "(function(){" +
            "try{" +
            "var k='metflix_admin_config_v9';" +
            "var c=JSON.parse(localStorage.getItem(k)||'{}');" +
            "c.embedServer='" + server + "';" +
            "c.defaultLang='" + audio + "';" +
            "c.defaultSub='" + sub + "';" +
            "c.defaultQuality='" + quality + "';" +
            "c.oneServer=" + (!autoSwitch) + ";" +
            "c.keepServerOnError=" + keepServer + ";" +
            "localStorage.setItem(k,JSON.stringify(c));" +
            "}catch(e){}" +
            "})();";
        webView.evaluateJavascript(js, null);
    }

    private void exitFullscreen() {
        if (customView == null) return;
        fullscreenContainer.removeView(customView);
        fullscreenContainer.setVisibility(View.GONE);
        customView = null;
        if (customViewCallback != null) {
            customViewCallback.onCustomViewHidden();
            customViewCallback = null;
        }
        settingsFab.setVisibility(View.VISIBLE);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED);
        showSystemUI();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (webView != null) {
            syncPreferencesToWeb();
            if (SettingsActivity.settingsChanged) {
                SettingsActivity.settingsChanged = false;
                webView.reload();
            }
        }
    }

    private void hideSystemUI() {
        getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
            | View.SYSTEM_UI_FLAG_FULLSCREEN
            | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
            | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
            | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
            | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
        );
    }

    private void showSystemUI() {
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_VISIBLE);
    }

    @Override
    public void onBackPressed() {
        if (customView != null) {
            exitFullscreen();
            return;
        }
        if (webView.canGoBack()) {
            webView.goBack();
            return;
        }
        long now = System.currentTimeMillis();
        if (now - lastBackPressTime < 2000) {
            super.onBackPressed();
        } else {
            lastBackPressTime = now;
            Toast.makeText(this, "Press back again to exit METFLIX", Toast.LENGTH_SHORT).show();
        }
    }
}
