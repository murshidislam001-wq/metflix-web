# METFLIX Android App (WebView + Ad-Blocker + App Settings)

Wraps `https://metflixstream.netlify.app` into a native Android APK with:
- Built-in Pop-up & Redirect Blocker (`shouldOverrideUrlLoading` & `onCreateWindow`)
- Ad-Domain Request Filter (`shouldInterceptRequest`)
- Fullscreen Landscape Video Player
- Native **App & Player Settings** screen (Downloads: Internal / 1DM, Video Quality, Subtitles, Hindi/Multi-Lang Audio, Error Handling Rules, Ad-Block Shield, and Server Priority)

## How to Build the APK on GitHub (No PC Required)
1. Create a new repository on GitHub (e.g., `metflix-android`).
2. Upload all files from this folder to the repository.
3. Open the **Actions** tab on GitHub and wait ~2 minutes for **Build Metflix Android APK** to finish.
4. Tap the finished workflow run and download **Metflix-Android-APK** (`app-debug.apk`).
